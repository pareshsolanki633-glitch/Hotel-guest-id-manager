import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hotelguestid.manager',
  appName: 'Hotel Guest ID Manager',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
